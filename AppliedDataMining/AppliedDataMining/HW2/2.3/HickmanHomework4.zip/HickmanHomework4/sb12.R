##Homework 2.3##

summary(mydata)

mydata.na <- mydata[is.na(mydata)]
summary(mydata.na)
View(mydata.na)
