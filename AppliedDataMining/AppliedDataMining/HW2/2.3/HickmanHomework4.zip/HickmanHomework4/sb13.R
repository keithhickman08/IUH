##Homework 2.3##

## Using the R function - filter(mydata, !complete.cases(mydata) ) - returns the entire dataset as NA. 
summary(mydata)
