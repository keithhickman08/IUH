##Homework 2.3##
##Script 1##

install.packages("data.table")

library(data.table)
library(ISLR)

mydata <- OJ
dim(mydata)